extends CharacterBody3D
@export_category("Mouse Settings")
@export var mouse_sensitivity = 0.002
@export var upDownLimit = 80.0

@export_category("Movement Settings")

@export var walkSpeed = 4.0

@export var gravity = 19.8

@onready var LeftHand = $CameraPivot/SpringArm3D/Camera3D/Lhand

@onready var RightHand = $CameraPivot/SpringArm3D/Camera3D/Rhand
@onready var left_hand_idle_local: Vector3 = LeftHand.position
@onready var right_hand_idle_local: Vector3 = RightHand.position
@onready var Cam = $CameraPivot/SpringArm3D/Camera3D
@onready var CamPiv = $CameraPivot
@onready var CamSwaySpeed = 5.0

@onready var leftTargetArea: Area3D = null
@onready var rightTargetArea: Area3D = null

@export var maxReachDistance = 2.0
@export_category("Climbing Settings")
@export var reachForce = 15.0
const JUMP_VELOCITY = 10

#cam stuff
var rot_x = 0.0
var rot_y = 0.0


func _ready() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
#Hand States are here: 
var IsLeftGrabbing = false
var IsRightGrabbing = false
var LeftGrabPoint: Vector3
var RightGrabPoint: Vector3

func _physics_process(delta: float) -> void:
	update_camera_position(delta)
	if not is_on_floor():
		velocity.y -= gravity * delta

	# 2. Handle Jump Input
	# "jump" must be configured in your Project Settings -> Input Map (usually bound to Spacebar)
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = JUMP_VELOCITY
	
	# Handle Walking / Gravity / Free Movement
	var input_dir: Vector2 = Input.get_vector("left", "right", "Forward", "Backwards")
	var direction: Vector3 = (transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()

	if not IsRightGrabbing and not IsLeftGrabbing:
		# --- MODE 1: FREE MOVEMENT ---
		# Return hands smoothly to their default local camera positions
		LeftHand.position = LeftHand.position.move_toward(left_hand_idle_local, delta * 5.0)
		RightHand.position = RightHand.position.move_toward(right_hand_idle_local, delta * 5.0)
		
		if direction != Vector3.ZERO:
			velocity.x = direction.x * walkSpeed
			velocity.z = direction.z * walkSpeed
		else:
			velocity.x = move_toward(velocity.x, 0, walkSpeed)
			velocity.z = move_toward(velocity.z, 0, walkSpeed)
		velocity.y -= gravity * delta
		
	else:
		# --- MODE 2: CLIMBING ACTIVE ---
		var pull_vector: Vector3 = Vector3.ZERO
		var pull_count: int = 0

		# Cache current camera/shoulder positions in global space
		var head_pos = Cam.global_position
		var left_shoulder_global = Cam.global_transform * left_hand_idle_local
		var right_shoulder_global = Cam.global_transform * right_hand_idle_local

		if IsLeftGrabbing:
			LeftHand.global_position = LeftGrabPoint
			# Vector from shoulder up to the hold
			pull_vector += (LeftGrabPoint - left_shoulder_global)
			pull_count += 1
			
			if (LeftGrabPoint - left_shoulder_global).length() > maxReachDistance:
				IsLeftGrabbing = false

		if IsRightGrabbing:
			RightHand.global_position = RightGrabPoint
			# Vector from shoulder up to the hold
			pull_vector += (RightGrabPoint - right_shoulder_global)
			pull_count += 1
			
			if (RightGrabPoint - right_shoulder_global).length() > maxReachDistance:
				IsRightGrabbing = false

		if pull_count > 0:
			var average_pull = pull_vector / pull_count
			
			# 1. SPLIT VERTICAL AND HORIZONTAL FORCES
			var vertical_force = average_pull.y * reachForce
			
			# 2. BOOST THE UPWARD MOMENTUM
			# If the hold is above your head/shoulders, give it an extra upward hoist
			if average_pull.y > 0:
				vertical_force *= 1.8 
			else:
				# If hold is below you, allow you to hang/mantle safely
				vertical_force *= 0.5

			# 3. PREVENT WALL CLIPPING (Horizontal Dampening)
			# Find the direction directly facing the wall using your horizontal camera angle
			var forward_dir = -CamPiv.global_transform.basis.z
			forward_dir.y = 0
			forward_dir = forward_dir.normalized()
			
			# Flatten the horizontal pull so it doesn't aggressively bury you inside the mesh
			var horizontal_pull = Vector3(average_pull.x, 0, average_pull.z)
			
			# Combine forces: Strong upward hoist + smooth horizontal tracking
			velocity.y = vertical_force
			velocity.x = horizontal_pull.x * (reachForce * 0.5)
			velocity.z = horizontal_pull.z * (reachForce * 0.5)
			
			# 4. CRISPY MANTLE PUSH: If your chest is practically touching the hold, 
			# tap into input directions to let the player hoist themselves over the lip!
			var input_dir_vec: Vector2 = Input.get_vector("left", "right", "Forward", "Backwards")
			if input_dir.y < 0: # Pressing Forward / Up
				velocity.y += reachForce * 0.5
				velocity += forward_dir * (walkSpeed * 0.3)

		else:
			velocity = Vector3.ZERO

	move_and_slide()

func update_camera_position(delta: float) -> void:
	# Calculate the midpoint between the two hands in local space
	var target_local_pos: Vector3 = (LeftHand.position + RightHand.position) / 2.0
	
	# Shift the target position up slightly so your eyes sit above your hands
	target_local_pos.y += 0.5 
	
	# Smoothly interpolate (lerp) the pivot position to match the hand midpoint
	# This creates the physical 'heaviness' and sway when moving your hands
	CamPiv.position = CamPiv.position.lerp(target_local_pos, CamSwaySpeed * delta)
	
	#HAND GRABS! ->
	
	
func _on_left_hand_area_entered(area: Area3D) -> void:
	leftTargetArea = area
	print("Left hand can grab: ", area.name)


func _on_right_hand_area_entered(area: Area3D) -> void:
	rightTargetArea = area
	print("Right hand can grab: ", area.name)


func _on_left_hand_input_event(camera: Node, event: InputEvent, event_position: Vector3, normal: Vector3, shape_idx: int) -> void:
	if event.is_action_pressed("GrabLeft"):
		IsLeftGrabbing = true
		LeftGrabPoint = position
		print("Left hand grab")

func _unhandled_input(event: InputEvent) -> void:
	# Mouse toggle
	if event.is_action_pressed("ui_cancel"):
		if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
			Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
		else:
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

	# Camera rotation
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		rotate_y(-event.relative.x * mouse_sensitivity)
		CamPiv.rotate_x(-event.relative.y * mouse_sensitivity)
		var clamped_rotation = clamp(CamPiv.rotation.x, deg_to_rad(-upDownLimit), deg_to_rad(upDownLimit))
		CamPiv.rotation.x = clamped_rotation

	# GRAB!
	if event.is_action_pressed("GrabLeft"):
		if leftTargetArea != null:
			IsLeftGrabbing = true
			LeftGrabPoint = leftTargetArea.global_position

	if event.is_action_pressed("GrabRight"):
		if rightTargetArea != null:
			IsRightGrabbing = true
			RightGrabPoint = rightTargetArea.global_position

	# RELEASE!
	if event.is_action_released("GrabLeft"):
		IsLeftGrabbing = false

	if event.is_action_released("GrabRight"):
		IsRightGrabbing = false
	

func _on_right_hand_input_event(camera: Node, event: InputEvent, event_position: Vector3, normal: Vector3, shape_idx: int) -> void:
	if event.is_action("GrabRight"):
		IsRightGrabbing = true
		RightGrabPoint = position
		print("Right hand grab")


func _on_rhand_area_exited(area: Area3D) -> void:
	if rightTargetArea == area:
		rightTargetArea = null
	pass # Replace with function body.


func _on_lhand_area_exited(area: Area3D) -> void:
	if leftTargetArea == area:
		leftTargetArea = null
	pass # Replace with function body.

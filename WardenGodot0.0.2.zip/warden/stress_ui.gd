extends Control
@onready var hptag = $TextureRect/HealthStat
@onready var nametag = $TextureRect/NameOFPrisoner

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	hptag.add_text(GlobalScriptthing.Pris_name)
	
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

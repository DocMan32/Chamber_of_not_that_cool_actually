extends Node
@onready var Pris_Noise = 10
@onready var Pris_Damage = 10
@onready var Pris_name
signal energy_updated(current_energy)
signal game_over

@export var max_energy: float = 8.0
var current_energy: float = max_energy

func use_energy(amount: float):
	current_energy -= amount
	emit_signal("energy_updated", current_energy)
	if current_energy <= 0.0:
		emit_signal("OUT OF ENERGY!")
		

func recharge_energy():
	current_energy = max_energy
	emit_signal("Energy Updated!", current_energy)
	

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	
	var randomthing = randi_range(0, 5)
	print(randomthing)
	
	if randomthing == 1:
		Pris_name = "Barry"
	if randomthing == 2:
		Pris_name = "Louis"
	if randomthing == 3:
		Pris_name = "Jerry"
	if randomthing == 4:
		Pris_name = "Ben"
	if randomthing == 5:
		Pris_name = "Ashley"
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	
	pass

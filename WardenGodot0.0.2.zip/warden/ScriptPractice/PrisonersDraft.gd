extends CharacterBody2D

enum State { IDLE, MOVE_TO, HIDE, STEALTH }
var current_state: State = State.IDLE
var target_position: Vector2

@onready var nav_agent: NavigationAgent2D = $NavigationAgent2D

func updateOrders(new_state: State, new_target: Vector2):
	current_state = new_state
	target_position = new_target
	nav_agent.target_position = target_position
	
func _physics_process(delta: float) -> void:
	if current_state == State.MOVE_TO:
		var dir = global_position.direction_to(nav_agent.get_next_path_position())
		velocity = dir * 150
		move_and_slide()
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

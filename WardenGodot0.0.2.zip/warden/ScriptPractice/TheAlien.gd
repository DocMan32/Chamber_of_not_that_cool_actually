extends CharacterBody2D

enum State { PATROL, HUNT, VENT_TUNNEL }
var current_state: State = State.PATROL

@export var AlienSpeed: float = 300.0
@onready var nav_agent: NavigationAgent2D = $NavigationAgent2D

func _physics_process(delta: float) -> void:
	#Simple AI loop
	match current_state:
		State.HUNT:
			#Navigate towards prisoner / noise
			pass
		State.VENT_TUNNEL:
			#Warp through station vents
			pass

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

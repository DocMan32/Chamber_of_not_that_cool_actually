extends Control

@onready var motion_tracker: Timer = $MotionTrackerTimer
@onready var camera_feed: TextureRect = $CamFeed

var is_cam_active: bool = false
var drain_rate: float = 0.5 #Energy per second thing



# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	
	if is_cam_active:
		GlobalScriptthing.use_energy(drain_rate * delta)
		

func toggle_cam_feed(turn_on: bool):
	is_cam_active = turn_on
	camera_feed.visible = turn_on
	
func ping_motion_tracker():
	GlobalScriptthing.use_energy(0.5)
	print("Pinging Tracker for Alien Proximity")
	

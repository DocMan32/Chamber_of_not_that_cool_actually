extends Area2D

@onready var sprite: Sprite2D = $Sprite2D
@export var is_sealed: bool = false
var door_seal_cost: float = 1.0

#Xenomorph patrols the station use navigation reigon 2d, for the mpa with the alien moving as a 
# ACharacter2D navigating uising the navigation agent 2D, doors act as choke points.

func toggle_seal():
	is_sealed = !is_sealed
	if is_sealed:
		GlobalScriptthing.use_energy(door_seal_cost)
		sprite.modulate = Color.RED # DOOR IS SEALED
	else:
		sprite.modulate = Color.GREEN # DOOR IS OPEN


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

extends Control


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_map_pressed() -> void:
	get_tree().change_scene_to_file("res://Main.tscn") # Replace with function body.


func _on_stress_pressed() -> void:
	get_tree().change_scene_to_file("res://StressUI.tscn")

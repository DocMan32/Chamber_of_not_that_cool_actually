extends Node2D
@onready var path_follow_2d: PathFollow2D = $Path2D/PathFollow2D
@onready var line_2d: Line2D = $Line2D
@onready var path_2d: Path2D = $Path2D

var is_drawing = false

func _input(event):
	# Start drawing
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			is_drawing = true
			line_2d.clear_points()
			path_2d.curve.clear_points()
			_add_point(event.position)
		else:
			is_drawing = false
			_start_player_movement()

	# Continue drawing
	elif event is InputEventMouseMotion and is_drawing:
		_add_point(event.position)

func _add_point(pos: Vector2):
	line_2d.add_point(pos)
	path_2d.curve.add_point(pos)


var speed = 200.0
var is_moving = false

func _process(delta):
	if is_moving:
		# Increment progress along the curve
		path_follow_2d.progress += speed * delta
		
		# Stop when reaching the end of the path
		if path_follow_2d.progress_ratio >= 1.0:
			is_moving = false

func _start_player_movement():
	path_follow_2d.progress = 0.0 # Reset to start
	is_moving = true

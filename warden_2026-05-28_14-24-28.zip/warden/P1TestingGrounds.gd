extends CharacterBody2D
@export var speed: float = 50.0
var targetPos : Vector2 = Vector2.ZERO


# Called when the node enters the scene tree for the first time.
func _ready():
	await get_tree().physics_frame
	pass


func _physics_process(delta: float) -> void:
	# Calculate the direction to the target and normalize it
	var direction = global_position.direction_to(targetPos)
	
	# Check if we are close enough to the target to stop (to prevent jittering)
	if global_position.distance_to(targetPos) > 5.0:
		velocity = position.direction_to(targetPos) * speed
		move_and_slide()
	else:
		velocity = Vector2.ZERO # Stop moving when close enough
	


func _on_area_2d_input_event(viewport: Node, event: InputEvent, shape_idx: int) -> void:
	if event.is_action_pressed("Click"):
		targetPos = get_global_mouse_position()
		var text = $"../MainUI/RichTextLabel"
		var PrisPort = $"../MainUI/Sprite2D"
		PrisPort.visible = true
		text.add_text("I made it!")


func _on_speedup_pressed() -> void:
	speed += 10
	GlobalScriptthing.Pris_Noise += 10
	print("Careful! Your noise level is: ", GlobalScriptthing.Pris_Noise)
	if GlobalScriptthing.Pris_Noise >= 50:
		print("Prisoners are creating a lot of noise. Keep it up and you'll be joining them.")
		



func _on_slow_pressed() -> void:
	if speed == 10:
		return
	speed -= 10
	if GlobalScriptthing.Pris_Noise == 10:
		return
	
	GlobalScriptthing.Pris_Noise -= 10
	print("SHH your current noise level: ", GlobalScriptthing.Pris_Noise)

#switching tabs
func _on_texture_button_pressed() -> void:
	
	pass # Replace with function body.

#takes you to stats screen for stress

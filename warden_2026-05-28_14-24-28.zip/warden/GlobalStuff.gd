extends Node
@onready var Pris_Noise = 10
@onready var Pris_Damage = 10
@onready var Pris_name
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	
	var randomthing = randi_range(0, 5)
	print(randomthing)
	
	if randomthing == 1:
		Pris_name = "Barry"
	if randomthing == 2:
		Pris_name = "Louis"
	if randomthing == 3:
		Pris_name = "Jerry"
	if randomthing == 4:
		Pris_name = "Ben"
	if randomthing == 5:
		Pris_name = "Ashley"
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	
	pass

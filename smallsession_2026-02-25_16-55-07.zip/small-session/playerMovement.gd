extends CharacterBody2D


const BULLET = preload("res://Bullet.tscn")
const SPEED = 300.0
const JUMP_VELOCITY = -400.0


func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity += get_gravity() * delta


	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		velocity.y = JUMP_VELOCITY



	var direction := Input.get_axis("ui_left", "ui_right")
	if direction:
		velocity.x = direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)
	
	if Input.is_action_just_pressed("Shoot"):
		var b = BULLET.instantiate()
		b.global_position = $gun/RayCast2D/Pistol/Marker2D.global_position
		b.global_rotation = $gun/RayCast2D/Pistol/Marker2D.global_rotation
		get_tree().root.add_child(b)
		

	move_and_slide()
	
	
	
	
	
	
	


func _on_enemy_area_entered(area: Area2D) -> void:
	print("ENEMY HIT")
	visibility_changed
	

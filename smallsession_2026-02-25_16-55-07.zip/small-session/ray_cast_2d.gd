extends RayCast2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	#rotation = get_global_mouse_position().angle_to_point(position)
	look_at(get_global_mouse_position())
	if MOUSE_BUTTON_LEFT:
		get_global_mouse_position()
